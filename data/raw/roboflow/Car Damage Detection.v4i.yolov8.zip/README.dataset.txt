# Car Damage Detection > 2023-07-11 9:49pm
https://universe.roboflow.com/capstone-nh0nc/car-damage-detection-t0g92

Provided by a Roboflow user
License: CC BY 4.0

